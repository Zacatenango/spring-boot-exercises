package com.example.zacatenango.initialbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitialBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
